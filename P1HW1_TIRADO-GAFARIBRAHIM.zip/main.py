num1 = int(input("Enter your first number\n"))
num2 = int(input("Enter your second number\n"))
num_mult = num1*num2
num_sum = num1+num2

print(num1)
print(num2)
print(num_sum)
print(num_mult)
