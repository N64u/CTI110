r = int(input())
g = int(input())
b = int(input())
smallest = 0

if (r < g) and (r < b):
    smallest = r
    
elif (g < b):
    smallest = g

else:
    smallest = b
r -= smallest
g -= smallest
b -= smallest

print(r, g, b)