auto_service = input('Enter desired auto service:\n')
cost = '0'
print('You entered:', auto_service)
if auto_service == 'Oil change':
    auto_service = 'oil change'
    cost = '$35'
    print(f'Cost of {auto_service}: {cost}')
elif auto_service == 'Tire rotation':
    auto_service = 'tire rotation'
    cost = '$19'
    print(f'Cost of {auto_service}: {cost}')
elif auto_service == 'Car wash':
    auto_service = 'car wash'
    cost = '$7'
    print(f'Cost of {auto_service}: {cost}')
else:
    print('Error: Requested service is not recognized')

