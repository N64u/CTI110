user_text = input()

unwanted = " .!,"
char_count = 0

for character in user_text:

    if character not in unwanted:
        char_count += 1
        
print(char_count)