import turtle

wn = turtle.Screen()
wn.bgcolor("gray")
wn.title("P4LAB2a by Ibrahim Tirado-Gafar")

trianglet = turtle.Turtle()
trianglet.shape("blank")
trianglet.color("yellow")
trianglet.speed(1)

turtle.shape("blank")
turtle.color("red")

for triangle in range(3): #Executes i = 0, 1, 2, 
    trianglet.forward(80)
    trianglet.left(120)

turtle.right(90)

for square in range(4):      #Executes i = 0, then i = 1,then i = 2,then i = 3
    turtle.forward(80)
    turtle.left(90)
    

    
