import turtle

wn = turtle.Screen()
wn.bgcolor("black")
wn.title("P4LAB2b by Ibrahim Tirado-Gafar")

turtle.colormode(255)
turtle.color(235,92,52)
turtle.pensize(5)

for initial_I in range(1):
    turtle.forward(120)
    turtle.right(180)
    turtle.forward(60)
    turtle.left(90)
    turtle.forward(120)
    turtle.right(90)
    turtle.forward(60)
    turtle.right(180)
    turtle.forward(120)

for initial_T in range(1):
    turtle.penup()
    turtle.forward(100)
    turtle.pendown()
    turtle.left(90)
    turtle.forward(120)
    turtle.right(90)
    turtle.forward(70)
    turtle.right(180)
    turtle.forward(140)
    
    
