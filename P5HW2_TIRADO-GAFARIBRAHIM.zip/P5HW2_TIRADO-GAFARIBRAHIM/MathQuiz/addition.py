import math
import random
# brings from libary

#counter defualt
i = 0

#main function
def main():
    #ensures count default
    1 == 0
    # default text
    text = 'o'

    #function for addition
def addition():
    # confirms if they want to start function
    text = input('type "start" to begin addition quiz: ')
    while text == 'start':
        
        print("Addition Quiz Selected...")
        # while user keeps typing start program will remain
        while text == 'start':
            ran_num1 = random.randint(1,9)
            ran_num2 = random.randint(1,9)
            ran_problem = print(f' {ran_num1} \n+{ran_num2}')
            print('___')
            ran_problem_answer = ran_num1 + ran_num2
            user_answer = int(input(f'What is {ran_num1} + {ran_num2}?'))
            while user_answer != ran_problem_answer:
                # makes i global
                global i
                i +=1
                print(f'Incorrect attempt #{i}')
                # if user's answer is less than answer, it will print "Answer is too low!"
                if user_answer < ran_problem_answer:
                    print('Answer is too low!\n')
                # if user's answer is more than answer, it will print "Answer is too high!"
                if user_answer > ran_problem_answer:
                    print('Answer is too high!\n')
                # Ask user to enter answer again
                user_answer = int(input(f'What is {ran_num1} + {ran_num2}?: '))
            # if user answer equals the correct answer, then they will be asked if they want to continue
            if user_answer == ran_problem_answer:
                print('Congratulations!')
                print(f'It took you {i} tries!')
            # continue?
                text = input('enter something to exit, if you want to stay type "start" again: ')
addition()
if __name__ =="__main__":
    main()

