# This program imports functions depending on what the user chooses
# 5.9.22
# CTI-110 P5HW2 - Math Quiz
# Ibrahim Tirado-Gafar
#

ADDITION_choice = 1
SUBTRACTION_choice = 2
QUIT_choice = 3

# main function
def main():
    
    # default choice
    choice = 0
    
    while choice != QUIT_choice:

        #display menu
        display_menu()

        # user's choice
        choice = int(input('Enter your choice: '))

        # Perform function
        if choice == ADDITION_choice:
            import addition # imports addition function


        elif choice == SUBTRACTION_choice:
            import subtraction # imports subtraction function

        elif choice == QUIT_choice:
            print('Quitting program....')

        else:
            print("You've broken the program >:(")

# Display menu options
def display_menu():
    print(' MENU')
    print('1)  Addition')
    print('2)  Subtraction')
    print('3)  Quit')

if __name__ =="__main__":
    main()

    
