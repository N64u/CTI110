def laps_to_miles(user_laps):
    laps = user_laps
    miles = 0.25
    laps_to_miles = laps * miles
    return laps_to_miles
if __name__ == '__main__':
    print(f'{laps_to_miles(user_laps=float(input())):.2f}')